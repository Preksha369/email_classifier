from fastapi import FastAPI
from pydantic import BaseModel
from utils import mask_pii
from models import load_models, classify_email
import uvicorn

app = FastAPI()

vectorizer, classifier = load_models()

class EmailInput(BaseModel):
    email: str

@app.post("/classify")
def classify(input_data: EmailInput):
    masked_email, entities = mask_pii(input_data.email)
    category = classify_email(masked_email, vectorizer, classifier)
    return {
        "input_email_body": input_data.email,
        "list_of_masked_entities": entities,
        "masked_email": masked_email,
        "category_of_the_email": category
    }
