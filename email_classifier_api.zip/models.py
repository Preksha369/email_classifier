import joblib
from sklearn.svm import SVC

def load_models():
    vectorizer = joblib.load("saved_models/tfidf_vectorizer.pkl")
    model = joblib.load("saved_models/svm_model.pkl")
    return vectorizer, model

def classify_email(text, vectorizer, model):
    vec = vectorizer.transform([text])
    return model.predict(vec)[0]
