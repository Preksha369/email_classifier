import re
import spacy

nlp = spacy.load("en_core_web_sm")

def mask_pii(text):
    masked_text = text
    masked_entities = []

    regex_patterns = [
        (r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', 'email'),
        (r'\b\d{10}\b', 'phone_number'),
        (r'\b\d{4} \d{4} \d{4}\b', 'aadhar_num'),
        (r'\b(?:\d{4}[- ]?){3}\d{4}\b', 'credit_debit_no'),
        (r'\b\d{3}\b', 'cvv_no'),
        (r'\b(0[1-9]|1[0-2])\/([0-9]{2}|[0-9]{4})\b', 'expiry_no'),
    ]

    for pattern, label in regex_patterns:
        for match in re.finditer(pattern, masked_text):
            start, end = match.start(), match.end()
            entity = match.group()
            masked_text = masked_text.replace(entity, f"[{label}]", 1)
            masked_entities.append({
                "position": [start, end],
                "classification": label,
                "entity": entity
            })

    doc = nlp(text)
    for ent in doc.ents:
        if ent.label_ == "PERSON":
            label = "full_name"
        elif ent.label_ == "DATE":
            label = "dob"
        else:
            continue

        entity = ent.text
        start = ent.start_char
        end = ent.end_char

        if entity in masked_text:
            masked_text = masked_text.replace(entity, f"[{label}]", 1)
            masked_entities.append({
                "position": [start, end],
                "classification": label,
                "entity": entity
            })

    return masked_text, masked_entities
