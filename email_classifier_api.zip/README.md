# Email Classifier API

This project classifies support emails while preserving privacy using PII masking. Built with FastAPI and SVM.

## Features
- Masks emails, names, phone numbers, Aadhaar, and credit card details.
- Classifies emails into support categories.
- Exposes a clean JSON-based API.

## How to Run
```bash
pip install -r requirements.txt
python -m spacy download en_core_web_sm
uvicorn app:app --reload
```

## API Endpoint
POST `/classify`
```json
{
  "email": "Your email text here"
}
```

Response format:
```json
{
  "input_email_body": "...",
  "list_of_masked_entities": [...],
  "masked_email": "...",
  "category_of_the_email": "..."
}
```